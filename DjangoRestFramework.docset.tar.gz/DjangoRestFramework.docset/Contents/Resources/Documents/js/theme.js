$(function(){

    $('pre code').parent().addClass('prettyprint well');

});
